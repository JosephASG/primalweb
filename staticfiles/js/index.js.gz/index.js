window.addEventListener('DOMContentLoaded', () => {
    
})

/*const url = "https://firebasestorage.googleapis.com/v0/b/fir-storage-primal.appspot.com/o/apps%2FLooper%20-%20Setup.exe?alt=media&token=d5bd1162-5c68-4038-9b2a-b84b09a242ee"
const enlace = document.querySelector("#ref")
enlace.setAttribute('href', url)*/

